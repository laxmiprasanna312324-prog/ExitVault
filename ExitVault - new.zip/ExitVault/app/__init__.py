"""ExitVault application package."""

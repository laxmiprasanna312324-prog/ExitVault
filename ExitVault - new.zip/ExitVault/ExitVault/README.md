# ExitVault

A polished, self-contained hackathon MVP for **Verified Organizational Memory**.

Open `index.html` in a browser, or serve the folder locally:

```sh
python3 -m http.server 8080
```

Then visit `http://localhost:8080`.

## Demo route

1. Begin Priya Sharma's exit interview and show the conversational follow-up.
2. Open **Verification center** to show evidence (3 delayed deliveries out of 20), confidence, and the conflict.
3. Select **View source evidence** to show the Hindsight storage confirmation.
4. Open **Ask ExitVault** to show a six-month-later, evidence-aware handover answer.

The demo is intentionally static and self-contained so it can be presented immediately without credentials or external services.
